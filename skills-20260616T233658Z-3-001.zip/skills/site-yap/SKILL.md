---
name: site-yap
description: Profesyonel, benzersiz ve modern web siteleri oluşturma yeteneği.
---

# Site Yap Skill

Bu yetenek, projenin `.cursorrules` dosyasındaki tüm tasarım ve kalite kurallarına uyarak sıfırdan yaratıcı bir web sitesi oluşturur.

## İş Akışı

1.  **Bağlam Analizi**:
    - İşletme/kişi/proje ne tür bir iş yapıyor?
    - Hedef kitlesi kim?
    - Hangi hissiyat uygun? (Lüks, modern, sıcak, profesyonel, minimal...)
2.  **Estetik Yön Seçimi**:
    - **Font Kombinasyonu**: Google Fonts'tan KARAKTERLİ seçimler yap.
    - **Renk Paleti**: Bağlama özel, sıradan AI gradientlerinden uzak dur.
    - **Layout**: Asimetri, grid-breaking ve negatif alan kullan.
    - **Animasyon**: Scroll reveal ve hover sürprizleri planla.
    - **Atmosfer**: Texture, gradient mesh veya geometric pattern ekle.
3.  **Uygulama**:
    - Tek bir `index.html` dosyası oluştur.
    - Tüm CSS (`<style>`) ve JS (`<script>`) kodlarını dosya içinde topla.
    - Responsive tasarımı (375px → 1440px) en baştan düşün.
    - Tüm içeriği TÜRKÇE ve gerçekçi bir dille yaz (Lorem ipsum YASAK).
    - SEO etiketlerini, favicon'u ve Open Graph meta verilerini ekle.
4.  **Kalite Kontrol ve Gösterim**:
    - Dosyayı oluşturduktan sonra `open index.html` komutu ile tarayıcıda aç.
    - **Ekran Görüntüsü İş Akışını Uygula:** Tarayıcıyı kullanarak siteyi görsel olarak analiz et, referansla kıyasla (varsa) ve farklar kalmayana kadar düzelterek en az 2 tur görsel karşılaştırma yap. 
    - `.cursorrules` dosyasındaki "Kalite Kontrol Soruları"nı tek tek yanıtla.
    - Eğer tasarım "sıradan" veya "yapay zeka işi" gibi görünüyorsa, iyileştirmeler yap.

## Varsayılan Sayfa Bölümleri

Her site (bağlama göre değişebilir ama) şu 10 temel bölümü içermelidir:

1.  **Navigation (Navigasyon)**: Sticky/fixed. Logo + linkler + belirgin CTA butonu. Mobilde hamburger menü.
2.  **Hero (Giriş)**: İlk izlenim. Büyük, cesur, unutulmaz ve full-viewport yükseklik.
3.  **Sosyal Kanıt (Social Proof)**: Partner logoları, rakamlar veya kısa bir testimonial şeridi.
4.  **Hizmetler / Özellikler**: Ne sunuluyor? Neden önemli?
5.  **Hakkında / Nasıl Çalışır**: Güven oluşturma. 3 adımlık süreç veya kısa hikaye.
6.  **Galeri / Projeler**: Görsel vitrin (bağlam uygunsa).
7.  **Referanslar (Testimonials)**: Müşteri yorumları (İsim + fotoğraf + yorum).
8.  **SSS (FAQ)**: Accordion yapısı, smooth animasyonlar.
9.  **CTA (Son Çağrı)**: Güçlü başlık + buton + atmosferik arka plan.
10. **Footer (Alt Bilgi)**: İletişim, sosyal medya ikonları, linkler ve telif bilgisi.

## Önemli Notlar

- Her site BİRİNCİ SINIF ve BENZERSİZ görünmeli.
- Kesinlikle `transition-all` kullanma.
- Default Tailwind renklerinden ve fontlarından uzak dur.
- Cesur ol, beklenmeyeni yap ama kullanılabilirliği bozma.
